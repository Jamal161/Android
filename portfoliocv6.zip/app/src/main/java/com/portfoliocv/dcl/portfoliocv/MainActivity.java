package com.portfoliocv.dcl.portfoliocv;

import android.support.design.widget.AppBarLayout;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    private TabLayout tabLayout;
    private AppBarLayout appBarLayout;
    private ViewPager viewPager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tabLayout=(TabLayout) findViewById(R.id.tablayout_id);
        appBarLayout=(AppBarLayout) findViewById(R.id.appbarid);
        viewPager=(ViewPager) findViewById( R.id.viewpager_id);
        ViewpagerAdapter adapter=new ViewpagerAdapter(getSupportFragmentManager());
        //adding fragment
        adapter.AddFragment(new FragmentAbout(),"About");
        adapter.AddFragment(new FragmentResearchandPublication(),"Research and Publication");
        adapter.AddFragment(new FragmentContact(),"Contact");
        //adapter setup
        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }
}
